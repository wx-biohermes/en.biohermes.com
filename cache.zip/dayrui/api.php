<?php

/**
 * 访问检测
 */

header('Content-Type: text/html; charset=utf-8');


echo 'phpcmf ok';exit;