<?php

/**
 * Cms 移动端入口程序
 */

define('IS_MOBILE', 1);

// 执行主程序
require '../index.php';