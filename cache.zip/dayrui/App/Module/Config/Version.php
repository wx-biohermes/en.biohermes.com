<?php

return [

    'id' => '1289',
    'vip' => '1',
    'cms' => '4.7.1',
    'version' => '5.0',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2025-10-29 13:17:15',
    'downtime' => '2025-12-04 00:40:57',

];
