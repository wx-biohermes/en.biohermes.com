<?php

return [

    'type' => 'app',
    'name' => dr_lang('建站系统高级版'),
    'author' => dr_lang('迅睿VIP软件'),
    'icon' => 'fa fa-th-large',

];