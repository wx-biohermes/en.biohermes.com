<?php

/**
 * CSRF过滤白名单
 */

return [

    'home' => [
        'module/api/related',
        'member/api/related',
    ],

];