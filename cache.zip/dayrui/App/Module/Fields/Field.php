<?php

return [

    [
        'id' => 'Redirect',
        'name' => '转向链接',
        'used' => ['module'],
    ],

    [
        'id' => 'Catids',
        'name' => '副栏目',
        'used' => ['module'],
    ],

    [
        'id' => 'Cat',
        'name' => '模块栏目（单选）',
    ],

    [
        'id' => 'Cats',
        'name' => '模块栏目（多选）',
    ],

    [
        'id' => 'Related',
        'name' => '内容关联',
    ],

];