<?php

return [

    'type' => 'app',
    'name' => 'Sitemap',
    'author' => '迅睿官方',
    'icon' => 'fa fa-sitemap',

];