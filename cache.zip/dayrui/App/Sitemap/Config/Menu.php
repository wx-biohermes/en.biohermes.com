<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [


                'app-plugin' => [
                    'link' => [
                        'app-sitemap' => [
                            'name' => 'Sitemap',
                            'icon' => 'fa fa-sitemap',
                            'uri' => 'sitemap/home/index',
                        ],

                    ]
                ],
            ],



        ],

    ],
];