<?php

return [

    'type' => 'app',
    'name' => '全局网站表单',
    'author' => '迅睿官方',
    'icon' => 'fa fa-table',
    'uri' => 'form/form/index'

];