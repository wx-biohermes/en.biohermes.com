<?php

return [

    'id' => '710',
    'vip' => '1',
    'cms' => '4.6.3',
    'version' => '2.5',
    'license' => '',
    'updatetime' => '2024-10-23 13:40:58',
    'downtime' => '2024-11-19 09:01:13',

];
