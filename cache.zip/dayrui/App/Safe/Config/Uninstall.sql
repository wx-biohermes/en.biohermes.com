DROP TABLE IF EXISTS `{dbprefix}app_login`;

