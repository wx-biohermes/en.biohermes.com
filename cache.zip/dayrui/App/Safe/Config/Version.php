<?php

return [

    'id' => '399',
    'vip' => '1',
    'cms' => '4.7.1',
    'version' => '4.11',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2025-04-11 08:54:45',
    'downtime' => '2025-12-04 00:40:57',

];
