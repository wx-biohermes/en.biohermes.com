<?php

return [

    'type' => 'app',
    'name' => '系统安全',
    'author' => '迅睿VIP软件',
    'icon' => 'fa fa-shield',
    'uri' => 'safe/config/index'

];