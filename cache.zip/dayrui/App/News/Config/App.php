<?php

return [

    'type' => 'module',
    'name' => dr_lang('文章'),
    'icon' => 'fa fa-sticky-note',
    'system' => '1',
    'mtype' => '1'

];