<?php

return [

    [
        'id' => 'Score',
        'name' => '用户组设定值',
    ],
    [
        'id' => 'Members',
        'name' => '用户关联',
    ],

];