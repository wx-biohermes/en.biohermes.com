<?php

return [

    'id' => '782',
    'vip' => '1',
    'cms' => '4.7.1',
    'version' => '1.16',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2024-12-11 13:39:10',
    'downtime' => '2025-12-04 00:40:57',

];
