<?php

/**
 * 菜单配置
 */


return [

    'admin' => [

        'app' => [

            'left' => [


                'app-plugin' => [
                    'link' => [
                        'app-bdts' => [
                            'name' => '百度主动推送',
                            'icon' => 'fa fa-internet-explorer',
                            'uri' => 'bdts/home/index',
                        ],

                    ]
                ],
            ],



        ],

    ],
];