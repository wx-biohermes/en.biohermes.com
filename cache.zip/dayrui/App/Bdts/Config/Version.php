<?php

return [

    'id' => '426',
    'vip' => '1',
    'cms' => '4.6.3',
    'version' => '3.13',
    'license' => '',
    'updatetime' => '2024-02-21 02:13:05',
    'downtime' => '2024-11-19 16:22:35',

];
