<?php

return [

    'type' => 'app',
    'name' => '百度推送',
    'author' => '迅睿官方',
    'icon' => 'fa fa-internet-explorer',
    'uri' => 'bdts/home/index',

];