{php $my=$value;}{$my.seo.list_title}
{php $my=$value;}{$my.seo.list_keywords}
{php $my=$value;}{$my.seo.list_description}
