普通输出：{$value}
<hr>相对路径
去掉pc域名部分： {dr_rp($value, SITE_URL, '/')}
去掉手机域名部分： {dr_rp($value, SITE_MURL, '/')}