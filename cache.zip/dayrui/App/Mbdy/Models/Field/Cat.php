栏目名称：{dr_cat_value('填写模块目录或者共享栏目填写字母：share', $value, 'name')}
栏目地址：{dr_cat_value('填写模块目录或者共享栏目填写字母：share', $value, 'url')}
栏目缩略图：{dr_get_file(dr_cat_value('填写模块目录或者共享栏目填写字母：share', $value, 'thumb'))}

父栏目名称：{dr_cat_value('填写模块目录或者共享栏目填写字母：share', dr_cat_value('填写模块目录或者共享栏目填写字母：share', $value, 'pid'), 'name')}
父栏目地址：{dr_cat_value('填写模块目录或者共享栏目填写字母：share', dr_cat_value('填写模块目录或者共享栏目填写字母：share', $value, 'pid'), 'url')}

更多栏目其他字段<字段标签生成工具>插件的：字段调用标签，栏目字段调用，菜单下填写指定的值的写法【$value】
