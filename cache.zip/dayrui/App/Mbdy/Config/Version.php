<?php

return [

    'id' => '190',
    'version' => '7.44',
    'license' => '5E632913BF096E49880CF8B92D53C99711',
    'updatetime' => '2025-03-20',
    'downtime' => '2025-03-20',

];
